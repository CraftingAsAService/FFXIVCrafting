<?php namespace App\Http\Controllers\Osmose;


class EorzeaController extends \App\Http\Controllers\Controller
{

	

}