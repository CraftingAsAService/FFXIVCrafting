<?php namespace App\Models\CAAS;

use Illuminate\Database\Eloquent\Model;

class Guardians extends _LibraBasic
{

	protected $table = 'guardians';

}