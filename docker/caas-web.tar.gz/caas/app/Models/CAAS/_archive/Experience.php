<?php

namespace App\Models\CAAS;

use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{

	protected $table = 'experience';
	public $timestamps = false;

}
