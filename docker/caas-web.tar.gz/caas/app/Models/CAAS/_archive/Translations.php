<?php

namespace App\Models\CAAS;

use Illuminate\Database\Eloquent\Model;

class Translations extends Model
{

	protected $table = 'translations';
	public $timestamps = false;

}