<?php namespace App\Models\CAAS;

use Illuminate\Database\Eloquent\Model;

class BaseParam extends _LibraBasic
{

	protected $table = 'baseparam';

}