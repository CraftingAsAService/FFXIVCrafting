<?php namespace App\Models\CAAS;

use Illuminate\Database\Eloquent\Model;

class Races extends _LibraBasic
{

	protected $table = 'races';

}