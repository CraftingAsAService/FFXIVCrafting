-- MySQL dump 10.13  Distrib 5.6.19, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ffxivcrafting
-- ------------------------------------------------------
-- Server version	5.6.19-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `baseparam`
--

DROP TABLE IF EXISTS `baseparam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baseparam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `baseparam_items`
--

DROP TABLE IF EXISTS `baseparam_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baseparam_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `baseparam_id` int(10) unsigned NOT NULL,
  `nq_amount` decimal(6,2) unsigned NOT NULL,
  `hq_amount` decimal(6,2) unsigned DEFAULT NULL,
  `nq_limit` smallint(6) DEFAULT NULL,
  `hq_limit` smallint(6) DEFAULT NULL,
  `bonus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `baseparam_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28290 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `career_classjob`
--

DROP TABLE IF EXISTS `career_classjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `career_classjob` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `career_id` int(11) NOT NULL,
  `classjob_id` int(11) NOT NULL,
  `amount` decimal(6,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classjob_id` (`career_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14053 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `careers`
--

DROP TABLE IF EXISTS `careers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `careers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('recipe','item') COLLATE utf8_unicode_ci NOT NULL,
  `identifier` int(11) NOT NULL,
  `level` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `careers_type_index` (`type`),
  KEY `careers_identifier_index` (`identifier`),
  KEY `careers_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=8415 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classjob`
--

DROP TABLE IF EXISTS `classjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classjob` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_job` tinyint(1) NOT NULL,
  `rank` smallint(5) unsigned NOT NULL,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  `abbr_en` int(10) unsigned NOT NULL,
  `abbr_ja` int(10) unsigned NOT NULL,
  `abbr_fr` int(10) unsigned NOT NULL,
  `abbr_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classjob_is_job_index` (`is_job`),
  KEY `classjob_rank_index` (`rank`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classjob_category`
--

DROP TABLE IF EXISTS `classjob_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classjob_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classjob_classjob_category`
--

DROP TABLE IF EXISTS `classjob_classjob_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classjob_classjob_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classjob_id` int(10) unsigned NOT NULL,
  `classjob_category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classjob_category_id` (`classjob_id`)
) ENGINE=InnoDB AUTO_INCREMENT=469 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classjob_items`
--

DROP TABLE IF EXISTS `classjob_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classjob_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `classjob_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classjob_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66619 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cluster_items`
--

DROP TABLE IF EXISTS `cluster_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cluster_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`cluster_id`)
) ENGINE=InnoDB AUTO_INCREMENT=353 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cluster_nodes`
--

DROP TABLE IF EXISTS `cluster_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cluster_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) NOT NULL,
  `description` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `x` decimal(7,4) NOT NULL,
  `y` decimal(7,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cluster_nodes_cluster_id_index` (`cluster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clusters`
--

DROP TABLE IF EXISTS `clusters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clusters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `placename_id` int(11) NOT NULL,
  `classjob_id` int(11) NOT NULL,
  `level` smallint(6) NOT NULL,
  `icon` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `x` decimal(7,4) NOT NULL,
  `y` decimal(7,4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clusters_placename_id_index` (`placename_id`),
  KEY `clusters_classjob_id_index` (`classjob_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7032 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `experience` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` smallint(6) NOT NULL,
  `experience` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `experience_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `guardians`
--

DROP TABLE IF EXISTS `guardians`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guardians` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `item_category`
--

DROP TABLE IF EXISTS `item_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `item_series`
--

DROP TABLE IF EXISTS `item_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_series` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `item_special_bonus`
--

DROP TABLE IF EXISTS `item_special_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_special_bonus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `item_ui_category`
--

DROP TABLE IF EXISTS `item_ui_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_ui_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemuikind_id` smallint(5) unsigned NOT NULL,
  `rank` smallint(5) unsigned NOT NULL,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_ui_category_itemuikind_id_index` (`itemuikind_id`),
  KEY `item_ui_category_rank_index` (`rank`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `item_ui_kind`
--

DROP TABLE IF EXISTS `item_ui_kind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_ui_kind` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemcategory_id` smallint(5) unsigned NOT NULL,
  `itemuicategory_id` smallint(5) unsigned NOT NULL,
  `classjobcategory_id` smallint(5) unsigned DEFAULT NULL,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `equip_level` smallint(5) unsigned NOT NULL,
  `rarity` smallint(5) unsigned NOT NULL,
  `has_hq` smallint(5) unsigned NOT NULL,
  `itemseries_id` smallint(5) unsigned NOT NULL,
  `itemspecialbonus_id` smallint(5) unsigned NOT NULL,
  `slot` smallint(5) unsigned NOT NULL,
  `min_price` smallint(5) unsigned DEFAULT NULL,
  `max_price` smallint(5) unsigned DEFAULT NULL,
  `materia` smallint(5) unsigned DEFAULT NULL,
  `untradable` tinyint(1) NOT NULL,
  `unique` tinyint(1) NOT NULL,
  `achievable` tinyint(1) NOT NULL,
  `rewarded` tinyint(1) NOT NULL,
  `color` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `items_itemcategory_id_index` (`itemcategory_id`),
  KEY `items_itemuicategory_id_index` (`itemuicategory_id`),
  KEY `items_slot_index` (`slot`),
  KEY `items_equip_level_index` (`equip_level`),
  KEY `items_level_index` (`level`),
  KEY `items_rank_index` (`rank`)
) ENGINE=InnoDB AUTO_INCREMENT=10155 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `items_npcs_shops`
--

DROP TABLE IF EXISTS `items_npcs_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items_npcs_shops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `npcs_shop_id` int(10) unsigned NOT NULL,
  `color` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `items_npcs_shops_item_id_index` (`item_id`),
  KEY `items_npcs_shops_npcs_shop_id_index` (`npcs_shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6166 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leve_rewards`
--

DROP TABLE IF EXISTS `leve_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leve_rewards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `classjob_id` int(11) NOT NULL,
  `level` smallint(6) NOT NULL,
  `amount` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`classjob_id`)
) ENGINE=InnoDB AUTO_INCREMENT=741 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `leves`
--

DROP TABLE IF EXISTS `leves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `classjob_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `level` smallint(6) NOT NULL,
  `amount` smallint(6) NOT NULL,
  `xp` int(11) NOT NULL,
  `xp_spread` smallint(6) NOT NULL,
  `gil` smallint(6) NOT NULL,
  `gil_spread` smallint(6) NOT NULL,
  `triple` smallint(6) NOT NULL,
  `type` enum('Town','Courier','Reverse Courier','Field','Gathering') COLLATE utf8_unicode_ci NOT NULL,
  `major_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `minor_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `notes` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classjob_id` (`item_id`),
  KEY `leves_level_index` (`level`),
  KEY `leves_type_index` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=520 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notebook_division`
--

DROP TABLE IF EXISTS `notebook_division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notebook_division` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcs`
--

DROP TABLE IF EXISTS `npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npcs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  `genus` enum('beast','shop') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `npcs_genus_index` (`genus`)
) ENGINE=InnoDB AUTO_INCREMENT=37080000003371 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcs_items`
--

DROP TABLE IF EXISTS `npcs_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npcs_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npcs_id` bigint(20) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`npcs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=762 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcs_place_name`
--

DROP TABLE IF EXISTS `npcs_place_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npcs_place_name` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npcs_id` bigint(20) unsigned NOT NULL,
  `placename_id` int(10) unsigned NOT NULL,
  `x` smallint(5) unsigned DEFAULT NULL,
  `y` smallint(5) unsigned DEFAULT NULL,
  `levels` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `triggered` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `placename_id` (`npcs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2772 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `npcs_shops`
--

DROP TABLE IF EXISTS `npcs_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `npcs_shops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `npcs_id` bigint(20) unsigned NOT NULL,
  `shop_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_id` (`npcs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `place_name`
--

DROP TABLE IF EXISTS `place_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `place_name` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region` int(10) unsigned NOT NULL,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `place_name_region_index` (`region`),
  KEY `place_name_name_en_index` (`name_en`)
) ENGINE=InnoDB AUTO_INCREMENT=1539 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quest_items`
--

DROP TABLE IF EXISTS `quest_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `classjob_id` int(11) NOT NULL,
  `level` smallint(6) NOT NULL,
  `amount` smallint(6) NOT NULL,
  `quality` smallint(6) NOT NULL,
  `notes` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`classjob_id`),
  KEY `quest_items_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `races`
--

DROP TABLE IF EXISTS `races`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `races` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recipe_elements`
--

DROP TABLE IF EXISTS `recipe_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipe_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recipe_reagents`
--

DROP TABLE IF EXISTS `recipe_reagents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipe_reagents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recipe_reagents_item_id_index` (`item_id`),
  KEY `recipe_reagents_recipe_id_index` (`recipe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14789 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recipes`
--

DROP TABLE IF EXISTS `recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `classjob_id` int(10) unsigned NOT NULL,
  `element_id` smallint(5) unsigned NOT NULL,
  `can_hq` tinyint(1) NOT NULL,
  `yields` smallint(5) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `level_view` smallint(5) unsigned NOT NULL,
  `stars` smallint(5) unsigned DEFAULT NULL,
  `req_craftsmanship` smallint(5) unsigned NOT NULL,
  `req_control` smallint(5) unsigned NOT NULL,
  `durability` smallint(5) unsigned NOT NULL,
  `max_quality` smallint(5) unsigned NOT NULL,
  `difficulty` smallint(5) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recipes_item_id_index` (`item_id`),
  KEY `recipes_classjob_id_index` (`classjob_id`),
  KEY `recipes_level_view_index` (`level_view`),
  KEY `recipes_rank_index` (`rank`)
) ENGINE=InnoDB AUTO_INCREMENT=30968 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shops`
--

DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` int(10) unsigned NOT NULL,
  `name_ja` int(10) unsigned NOT NULL,
  `name_fr` int(10) unsigned NOT NULL,
  `name_de` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=262497 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46482 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-08 17:25:48
