<?php return array (
  'app' => 
  array (
    'debug' => false,
    'url' => 'http://localhost',
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'key' => 'SomeRandomString',
    'cipher' => 'rijndael-128',
    'log' => 'daily',
    'providers' => 
    array (
      0 => 'Illuminate\\Foundation\\Providers\\ArtisanServiceProvider',
      1 => 'Illuminate\\Auth\\AuthServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Routing\\ControllerServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Illuminate\\Html\\HtmlServiceProvider',
      23 => 'Illuminate\\Redis\\RedisServiceProvider',
      24 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\BusServiceProvider',
      27 => 'App\\Providers\\ConfigServiceProvider',
      28 => 'App\\Providers\\EventServiceProvider',
      29 => 'App\\Providers\\RouteServiceProvider',
      30 => 'App\\Providers\\HelperServiceProvider',
      31 => 'Laracasts\\Flash\\FlashServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Input' => 'Illuminate\\Support\\Facades\\Input',
      'Inspiring' => 'Illuminate\\Foundation\\Inspiring',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Illuminate\\Html\\FormFacade',
      'HTML' => 'Illuminate\\Html\\HtmlFacade',
      'Flash' => 'Laracasts\\Flash\\Flash',
    ),
  ),
  'auth' => 
  array (
    'driver' => 'eloquent',
    'model' => 'App\\User',
    'table' => 'users',
    'password' => 
    array (
      'email' => 'emails.password',
      'table' => 'password_resets',
      'expire' => 60,
    ),
  ),
  'cache' => 
  array (
    'default' => 'redis',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/mnt/personal/ffxivcrafting/storage/framework/cache',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel',
  ),
  'compile' => 
  array (
    'files' => 
    array (
      0 => '/mnt/personal/ffxivcrafting/app/Providers/AppServiceProvider.php',
      1 => '/mnt/personal/ffxivcrafting/app/Providers/BusServiceProvider.php',
      2 => '/mnt/personal/ffxivcrafting/app/Providers/ConfigServiceProvider.php',
      3 => '/mnt/personal/ffxivcrafting/app/Providers/EventServiceProvider.php',
      4 => '/mnt/personal/ffxivcrafting/app/Providers/RouteServiceProvider.php',
    ),
    'providers' => 
    array (
    ),
  ),
  'database' => 
  array (
    'fetch' => 8,
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => '/mnt/personal/ffxivcrafting/storage/database.sqlite',
        'prefix' => '',
      ),
      'libra' => 
      array (
        'driver' => 'sqlite',
        'database' => '/mnt/personal/ffxivcrafting/database/app_data.sqlite',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => 'd792e90bbc00dfae3676c321ee16240a4454aa4b.rackspaceclouddb.com',
        'database' => 'caas',
        'username' => 'caasmin',
        'password' => 'secret',
        'charset' => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix' => '',
        'strict' => false,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => 'd792e90bbc00dfae3676c321ee16240a4454aa4b.rackspaceclouddb.com',
        'database' => 'caas',
        'username' => 'caasmin',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => 'd792e90bbc00dfae3676c321ee16240a4454aa4b.rackspaceclouddb.com',
        'database' => 'caas',
        'username' => 'caasmin',
        'password' => '',
        'prefix' => '',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'cluster' => false,
      'default' => 
      array (
        'host' => '127.0.0.1',
        'port' => 6379,
        'database' => 0,
      ),
    ),
  ),
  'experience' => 
  array (
    1 => 300,
    2 => 600,
    3 => 1100,
    4 => 1700,
    5 => 2300,
    6 => 4200,
    7 => 6000,
    8 => 7350,
    9 => 9930,
    10 => 11800,
    11 => 15600,
    12 => 19600,
    13 => 23700,
    14 => 26400,
    15 => 30500,
    16 => 35400,
    17 => 40500,
    18 => 45700,
    19 => 51000,
    20 => 56600,
    21 => 63900,
    22 => 71400,
    23 => 79100,
    24 => 87100,
    25 => 95200,
    26 => 109800,
    27 => 124800,
    28 => 140200,
    29 => 155900,
    30 => 162500,
    31 => 175900,
    32 => 189600,
    33 => 203500,
    34 => 217900,
    35 => 232320,
    36 => 249900,
    37 => 267800,
    38 => 286200,
    39 => 304900,
    40 => 324000,
    41 => 340200,
    42 => 356800,
    43 => 373700,
    44 => 390800,
    45 => 408200,
    46 => 437600,
    47 => 467500,
    48 => 498000,
    49 => 529000,
    50 => 864,
    51 => 1,
    52 => 1,
    53 => 1,
    54 => 1,
    55 => 2,
    56 => 2,
    57 => 2,
    58 => 3,
    59 => 3,
    60 => 217,
    61 => 600,
    62 => 592,
    63 => 0,
    64 => 995,
    65 => 200,
    66 => 427,
    67 => 200,
    68 => 888,
    69 => 0,
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/mnt/personal/ffxivcrafting/storage/app',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => 'your-key',
        'secret' => 'your-secret',
        'region' => 'your-region',
        'bucket' => 'your-bucket',
      ),
      'rackspace' => 
      array (
        'driver' => 'rackspace',
        'username' => 'your-username',
        'key' => 'your-key',
        'container' => 'your-container',
        'endpoint' => 'https://identity.api.rackspacecloud.com/v2.0/',
        'region' => 'IAD',
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.mailgun.org',
    'port' => 587,
    'from' => 
    array (
      'address' => NULL,
      'name' => NULL,
    ),
    'encryption' => 'tls',
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
    'pretend' => false,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'expire' => 60,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'ttr' => 60,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'queue' => 'your-queue-url',
        'region' => 'us-east-1',
      ),
      'iron' => 
      array (
        'driver' => 'iron',
        'host' => 'mq-aws-us-east-1.iron.io',
        'token' => 'your-token',
        'project' => 'your-project-id',
        'queue' => 'your-queue-name',
        'encrypt' => true,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'queue' => 'default',
        'expire' => 60,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => '',
      'secret' => '',
    ),
    'mandrill' => 
    array (
      'secret' => '',
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'stripe' => 
    array (
      'model' => 'User',
      'secret' => '',
    ),
  ),
  'session' => 
  array (
    'driver' => 'redis',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/mnt/personal/ffxivcrafting/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
  ),
  'site' => 
  array (
    'max_level' => 60,
    'cdn' => 'acd84eeb1b7b98b2dec5-9f5608ae56f41b0c88d873b8b4c5cc36.r22.cf2.rackcdn.com',
    'asset_cdn' => 'c3dcd810e2e5862353ca-bc79add51f9bad46177fcbc8055b750c.r72.cf2.rackcdn.com',
    'available_languages' => 
    array (
      0 => 'en',
    ),
    'full_languages' => 
    array (
      'en' => 'English',
      'fr' => 'Français',
      'de' => 'Deutsch',
      'ja' => '日本語',
    ),
    'default_language' => 'en',
    'cache_length' => '10080',
    'equipment_roles' => 
    array (
      0 => 'Main Hand',
      1 => 'Off Hand',
      2 => 'Head',
      3 => 'Body',
      4 => 'Hands',
      5 => 'Waist',
      6 => 'Legs',
      7 => 'Feet',
      8 => 'Neck',
      9 => 'Ears',
      10 => 'Wrists',
      11 => 'Right Ring',
      12 => 'Right Ring',
    ),
    'gear_focus' => 
    array (
      'LNC,PGL,DRG,MNK,BRD,ARC,ROG,NIN' => 
      array (
        0 => 'Dexterity',
        1 => 'Critical Hit Rate',
        2 => 'Skill Speed',
      ),
      'GLA,MRD,PLD,WAR' => 
      array (
        0 => 'Strength',
        1 => 'Skill Speed',
        2 => 'Parry',
      ),
      'THM,BLM,ACN,SMN' => 
      array (
        0 => 'Intelligence',
        1 => 'Spell Speed',
        2 => 'Piety',
      ),
      'CNJ,SCH,WHM' => 
      array (
        0 => 'Mind',
        1 => 'Spell Speed',
        2 => 'Piety',
      ),
      'CRP,BSM,ARM,GSM,LTW,WVR,ALC,CUL' => 
      array (
        0 => 'Control',
        1 => 'CP',
        2 => 'Craftsmanship',
      ),
      'MIN,BTN,FSH' => 
      array (
        0 => 'Gathering',
        1 => 'GP',
        2 => 'Perception',
      ),
    ),
    'job_ids' => 
    array (
      'crafting' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
      ),
      'gathering' => 
      array (
        0 => 16,
        1 => 17,
        2 => 18,
      ),
      'fishing' => 18,
      'basic_melee' => 
      array (
        0 => 1,
        1 => 2,
        2 => 3,
        3 => 4,
        4 => 5,
        5 => 29,
      ),
      'basic_magic' => 
      array (
        0 => 6,
        1 => 7,
        2 => 26,
      ),
      'advanced_melee' => 
      array (
        0 => 19,
        1 => 20,
        2 => 21,
        3 => 22,
        4 => 23,
        5 => 30,
      ),
      'advanced_magic' => 
      array (
        0 => 24,
        1 => 25,
        2 => 27,
        3 => 28,
      ),
    ),
    'defined_slots' => 
    array (
      1 => 'Main Hand',
      2 => 'Off Hand',
      3 => 'Head',
      4 => 'Body',
      5 => 'Hands',
      6 => 'Waist',
      7 => 'Legs',
      8 => 'Feet',
      9 => 'Ears',
      10 => 'Neck',
      11 => 'Wrists',
      12 => 'Right Ring',
      13 => 'Main Hand & Off Hand',
      15 => 'Body & Head',
      16 => 'Body, Hands, Legs & Feet',
      17 => 'Soul Crystal',
      18 => 'Legs & Feet',
      19 => 'Body, Head, Hands, Legs & Feet',
      21 => 'Body, Legs & Feet',
    ),
    'slot_alias' => 
    array (
      13 => 1,
      15 => 4,
      16 => 4,
      18 => 7,
      19 => 4,
      21 => 4,
    ),
    'slot_cannot_equip' => 
    array (
      13 => 
      array (
        0 => 2,
      ),
      15 => 
      array (
        0 => 3,
      ),
      16 => 
      array (
        0 => 5,
        1 => 7,
        2 => 8,
      ),
      18 => 
      array (
        0 => 8,
      ),
      19 => 
      array (
        0 => 3,
        1 => 5,
        2 => 7,
        3 => 8,
      ),
      21 => 
      array (
        0 => 7,
        1 => 8,
      ),
    ),
    'map' => 
    array (
      'shroud' => 
      array (
        'area' => 
        array (
          'id' => 23,
          'name' => 'The Black Shroud (Gridania)',
          'short_name' => 'Black Shroud',
          'img' => '/img/maps/the-black-shroud-the-black-shroud-region-01',
        ),
        'regions' => 
        array (
          'north' => 
          array (
            'id' => 57,
            'name' => '',
            'img' => '/img/maps/the-black-shroud-north-shroud-f1f4-00',
            'top' => '-120',
            'left' => '-90',
          ),
          'gridania' => 
          array (
            'id' => 51,
            'id_also' => '52,53',
            'name' => '',
            'img' => '/img/maps/the-black-shroud-gridania',
            'top' => '70',
            'left' => '220',
          ),
          'east' => 
          array (
            'id' => 55,
            'name' => '',
            'img' => '/img/maps/the-black-shroud-east-shroud-f1f2-00',
            'top' => '150',
            'left' => '560',
          ),
          'central' => 
          array (
            'id' => 54,
            'name' => '',
            'img' => '/img/maps/the-black-shroud-central-shroud-f1f1-00',
            'top' => '290',
            'left' => '110',
          ),
          'south' => 
          array (
            'id' => 56,
            'name' => '',
            'img' => '/img/maps/the-black-shroud-south-shroud-f1f3-00',
            'top' => '520',
            'left' => '310',
          ),
        ),
      ),
      'thanalan' => 
      array (
        'area' => 
        array (
          'id' => 24,
          'name' => 'Thanalan (Ul\'dah)',
          'short_name' => 'Thanalan',
          'img' => '/img/maps/thanalan-thanalan-region-02',
        ),
        'regions' => 
        array (
          'western' => 
          array (
            'id' => 42,
            'name' => '',
            'img' => '/img/maps/thanalan-western-thanalan-w1f1-00',
            'top' => '470',
            'left' => '20',
          ),
          'uldah' => 
          array (
            'id' => 39,
            'id_also' => '40,41',
            'name' => '',
            'img' => '/img/maps/thanalan-uldah---steps-of-thal',
            'top' => '530',
            'left' => '290',
          ),
          'southern' => 
          array (
            'id' => 45,
            'name' => '',
            'img' => '/img/maps/thanalan-southern-thanalan-w1f4-01',
            'top' => '470',
            'left' => '520',
          ),
          'northern' => 
          array (
            'id' => 46,
            'name' => '',
            'img' => '/img/maps/thanalan-northern-thanalan-w1f5-00',
            'top' => '-80',
            'left' => '210',
          ),
          'eastern' => 
          array (
            'id' => 44,
            'name' => '',
            'img' => '/img/maps/thanalan-eastern-thanalan-w1f3-00',
            'top' => '90',
            'left' => '530',
          ),
          'central' => 
          array (
            'id' => 43,
            'name' => '',
            'img' => '/img/maps/thanalan-central-thanalan-w1f2-00',
            'top' => '220',
            'left' => '230',
          ),
        ),
      ),
      'noscea' => 
      array (
        'area' => 
        array (
          'id' => 22,
          'name' => 'La Noscea (Limsa Lominsa)',
          'short_name' => 'La Noscea',
          'img' => '/img/maps/la-noscea-la-noscea-region-00',
        ),
        'regions' => 
        array (
          'western' => 
          array (
            'id' => 33,
            'name' => '',
            'img' => '/img/maps/la-noscea-western-la-noscea-s1f4-00',
            'top' => '110',
            'left' => '-80',
          ),
          'upper' => 
          array (
            'id' => 34,
            'name' => '',
            'img' => '/img/maps/la-noscea-upper-la-noscea-s1f5-00',
            'top' => '40',
            'left' => '220',
          ),
          'middle' => 
          array (
            'id' => 30,
            'name' => '',
            'img' => '/img/maps/la-noscea-middle-la-noscea-s1f1-00',
            'top' => '400',
            'left' => '250',
          ),
          'lower' => 
          array (
            'id' => 31,
            'name' => '',
            'img' => '/img/maps/la-noscea-lower-la-noscea-s1f2-00',
            'top' => '400',
            'left' => '400',
          ),
          'limsa' => 
          array (
            'id' => 27,
            'id_also' => '28,29',
            'name' => '',
            'img' => '/img/maps/la-noscea-limsa-lominsa',
            'top' => '550',
            'left' => '20',
          ),
          'eastern' => 
          array (
            'id' => 32,
            'name' => '',
            'img' => '/img/maps/la-noscea-eastern-la-noscea-s1f3-00',
            'top' => '0',
            'left' => '520',
          ),
          'outer' => 
          array (
            'id' => 350,
            'name' => '',
            'img' => '/img/maps/la-noscea-outer-la-noscea-s1f6-00',
            'top' => '0',
            'left' => '220',
          ),
        ),
      ),
      'coerthas' => 
      array (
        'area' => 
        array (
          'id' => 25,
          'id_also' => '26',
          'name' => 'Coerthas / Mor Dhona',
          'short_name' => 'Mor Dhona',
          'img' => '/img/maps/mor-dhona-mor-dhona-region-04',
        ),
        'regions' => 
        array (
          'coerthas-central' => 
          array (
            'id' => 63,
            'name' => '',
            'img' => '/img/maps/coerthas-coerthas-central-highlands-r1f1-00',
            'top' => '0',
            'left' => '40',
          ),
          'mor-dhona' => 
          array (
            'id' => 67,
            'name' => '',
            'img' => '/img/maps/mor-dhona-mor-dhona-l1f1-01',
            'top' => '380',
            'left' => '140',
          ),
        ),
      ),
    ),
    'servers' => 
    array (
      0 => 'Adamantoise',
      1 => 'Aegis',
      2 => 'Alexander',
      3 => 'Anima',
      4 => 'Asura',
      5 => 'Atomos',
      6 => 'Bahamut',
      7 => 'Balmung',
      8 => 'Behemoth',
      9 => 'Belias',
      10 => 'Brynhildr',
      11 => 'Cactuar',
      12 => 'Carbuncle',
      13 => 'Cerberus',
      14 => 'Chocobo',
      15 => 'Coeurl',
      16 => 'Diabolos',
      17 => 'Durandal',
      18 => 'Excalibur',
      19 => 'Exodus',
      20 => 'Faerie',
      21 => 'Famfrit',
      22 => 'Fenrir',
      23 => 'Garuda',
      24 => 'Gilgamesh',
      25 => 'Goblin',
      26 => 'Gungnir',
      27 => 'Hades',
      28 => 'Hyperion',
      29 => 'Ifrit',
      30 => 'Ixion',
      31 => 'Jenova',
      32 => 'Kujata',
      33 => 'Lamia',
      34 => 'Leviathan',
      35 => 'Lich',
      36 => 'Malboro',
      37 => 'Mandragora',
      38 => 'Masamune',
      39 => 'Mateus',
      40 => 'Midgardsormr',
      41 => 'Moogle',
      42 => 'Odin',
      43 => 'Pandaemonium',
      44 => 'Phoenix',
      45 => 'Ragnarok',
      46 => 'Ramuh',
      47 => 'Ridill',
      48 => 'Sargatanas',
      49 => 'Shinryu',
      50 => 'Shiva',
      51 => 'Siren',
      52 => 'Tiamat',
      53 => 'Titan',
      54 => 'Tonberry',
      55 => 'Typhon',
      56 => 'Ultima',
      57 => 'Ultros',
      58 => 'Unicorn',
      59 => 'Valefor',
      60 => 'Yojimbo',
      61 => 'Zalera',
      62 => 'Zeromus',
      63 => 'Zodiark',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/mnt/personal/ffxivcrafting/resources/views',
    ),
    'compiled' => '/mnt/personal/ffxivcrafting/storage/framework/views',
  ),
  'language' => 'en',
  'language_base_url' => 'localhost//',
);
