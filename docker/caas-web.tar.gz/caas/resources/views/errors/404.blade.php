@extends('app')

@section('banner')
	<h1>Page Not Found</h1>
@stop

@section('content')

<p>
	Should it have? Please use the links in the footer to get a hold of me!
</p>

<img src='/img/sad-moogle.png' width='392' class='img-responsive'>

@stop