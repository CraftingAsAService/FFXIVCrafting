@extends('app')

@section('banner')
<h1>
	Maintenance Mode
</h1>
@stop

@section('content')

<p>
	I'm currently updating the codebase.  We'll be right back.  Thanks for your patience.
</p>

<img src='/img/tour_moogle.png' style='position: relative; top: 30px;'>

@stop