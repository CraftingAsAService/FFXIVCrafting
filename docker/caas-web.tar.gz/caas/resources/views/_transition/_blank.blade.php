@extends('app')

@section('content')

<h1>Intentionally Left Blank</h1>

@stop