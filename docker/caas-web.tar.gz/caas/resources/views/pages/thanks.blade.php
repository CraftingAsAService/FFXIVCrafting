@extends('app')

@section('banner')
	<h1>Thank You!</h1>
@stop

@section('content')

	<h3>Your donations are greatly appreciated!</h3>

@stop