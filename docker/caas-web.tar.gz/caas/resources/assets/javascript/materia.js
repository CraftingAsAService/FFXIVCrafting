var materia = {
	init:function() {

	}
}

$(materia.init);